#!/bin/bash
python gradient_based_optimization.py two_param_compute $1 $2
