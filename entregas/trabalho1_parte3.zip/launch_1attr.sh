#!/bin/bash
python gradient_based_optimization.py one_param_compute $1 $2
