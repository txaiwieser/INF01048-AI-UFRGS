#!/bin/bash
## Não utilizado ja que o codigo não utiliza dependencias externas