#!/bin/bash
python main.py avalia_astar_h1 $1