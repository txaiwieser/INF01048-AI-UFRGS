#!/bin/bash
python main.py sucessor $1