#!/bin/bash
python main.py expande $1 $2