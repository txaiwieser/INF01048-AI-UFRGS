#!/bin/bash
python main.py avalia_bfs $1