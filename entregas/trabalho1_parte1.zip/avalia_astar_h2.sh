#!/bin/bash
python main.py avalia_astar_h2 $1