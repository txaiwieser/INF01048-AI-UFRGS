#!/bin/bash
python main.py avalia_dfs $1