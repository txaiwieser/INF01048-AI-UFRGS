#!/bin/bash
python customplayer.py $1 $2
